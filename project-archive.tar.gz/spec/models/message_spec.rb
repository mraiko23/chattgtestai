require 'rails_helper'

RSpec.describe Message, type: :model do
  # Example: Basic factory test
  # it 'can be created with factory' do
  #   record = create(:message)
  #   expect(record).to be_persisted
  # end
end
