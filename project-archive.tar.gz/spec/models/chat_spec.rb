require 'rails_helper'

RSpec.describe Chat, type: :model do
  # Example: Basic factory test
  # it 'can be created with factory' do
  #   record = create(:chat)
  #   expect(record).to be_persisted
  # end
end
